from django.shortcuts import render, redirect
from .models import Order
from django.http import HttpResponse

def create_order(request):
    if request.method == 'POST':
        customer_name = request.POST.get('customer_name')
        product_name = request.POST.get('product_name')
        quantity = int(request.POST.get('quantity', 1))

        # Create the order
        order = Order.objects.create(
            customer_name=customer_name,
            product_name=product_name,
            quantity=quantity
        )

        return HttpResponse(f"Order created successfully for {customer_name}. Invoice will be generated.")

    return render(request, 'create_order.html')
