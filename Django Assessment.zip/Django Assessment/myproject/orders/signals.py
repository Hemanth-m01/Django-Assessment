from django.db.models.signals import post_save
from django.dispatch import receiver
from django.db import transaction
from .models import Order, Invoice

@receiver(post_save, sender=Order)
def create_invoice_for_order(sender, instance, created, **kwargs):
    if created:
        with transaction.atomic():
            Invoice.objects.create(
                order=instance,
                amount=instance.quantity * 10.0
            )
